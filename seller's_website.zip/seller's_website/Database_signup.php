<?php
$conn=mysql_connect("localhost","root","");
if(!$conn)
{
die("not connect to server");
}
if(!mysql_select_db("website",$conn))
{
die("Not connect to database");

}
$Full_Name=$_POST['name'];
$Email=$_POST['email'];
$User_Name=$_POST['username'];
$Password=$_POST['pass'];
$Re_password=$_POST['repeat-pass'];
$sql="INSERT INTO signup(Full_Name,Email,User_Name,Password,Re_password)values('$Full_Name','$Email','$User_Name','$Password','$Re_passworde_password')";
if(mysql_query($sql))
{
echo "your data to inserted";
}
else
{
echo "not data insertted";
}
?>
