<?php
$conn=mysql_connect("localhost","root","");
if(!$conn)
{
die("not connect to server");
}
if(!mysql_select_db("website",$conn))
{
die("Not connect to database");

}
$Name=$_POST['username'];
$Password=$_POST['pass'];
$sql="INSERT INTO signin(Name,Password)values('$Name','$Password')";
if(mysql_query($sql))
{
echo "your data to inserted";
}
else
{
echo "not data insertted";
}
?>
